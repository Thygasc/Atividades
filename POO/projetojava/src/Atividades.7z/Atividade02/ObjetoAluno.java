package Atividade02;

public class ObjetoAluno {
    
    public static void main(String[] args) {
        //instanciar objeto aluno
        //    Aluno(String nome, String idade, String cor,boolean necessiadeespecial, String RA, String curso,String periodo){
        Aluno Thiago = new Aluno("Thiago","21","Pardo",false,"4454545","Sistemas de Informacao","2");
        Aluno Mayque = new Aluno("Mateus", "21", "Branco", true,"123456","ADS","5");
        Aluno Mateus = new Aluno("Maysa","20","Pardo",false,"54689","Biomedicina","4");
        Aluno Maria = new Aluno("Mayque","21","Negro", true,"645987","ADS","3");
        Aluno Maysa = new Aluno("Maria","18","Branca",false,"147852","Direito","1");
        Thiago.Ajudar();
        Thiago.Estudar();
        Thiago.Comprar();
        Thiago.Faltar();
        Thiago.Atividade();
        Thiago.Reclamar();
        Thiago.Passar();
        
        System.out.println("Nome:"+Thiago.getNome());
        System.out.println("Idade:"+Thiago.getIdade());
        System.out.println("Cor:"+Thiago.getCor());
        System.out.println("Necessidade Especial :"+Thiago.isNecessiadeespecial());
        System.out.println("RA :"+Thiago.getRA());
        System.out.println("curso:"+Thiago.getPeriodo());
        System.out.println("periodo:"+Thiago.getCurso());
        System.out.println("-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*--*-*");
        System.out.println("-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*--*-*");

        
        //MATEUS

        Mateus.Ajudar();
        Mateus.Estudar();
        Mateus.Comprar();
        Mateus.Faltar();
        Mateus.Atividade();
        Mateus.Reclamar();
        Mateus.Passar();
        
        System.out.println("Nome:"+Mateus.getNome());
        System.out.println("Idade:"+Mateus.getIdade());
        System.out.println("Cor:"+Mateus.getCor());
        System.out.println("Necessidade Especial :"+Mateus.isNecessiadeespecial());
        System.out.println("RA :"+Mateus.getRA());
        System.out.println("curso:"+Mateus.getPeriodo());
        System.out.println("periodo:"+Mateus.getCurso());
        System.out.println("-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*--*-*");
        System.out.println("-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*--*-*");
        //Maysa

        
        Maysa.Ajudar();
        Maysa.Estudar();
        Maysa.Comprar();
        Maysa.Faltar();
        Maysa.Atividade();
        Maysa.Reclamar();
        Maysa.Passar();
        
        System.out.println("Nome:"+Maysa.getNome());
        System.out.println("Idade:"+Maysa.getIdade());
        System.out.println("Cor:"+Maysa.getCor());
        System.out.println("Necessidade Especial :"+Maysa.isNecessiadeespecial());
        System.out.println("RA :"+Maysa.getRA());
        System.out.println("curso:"+Maysa.getPeriodo());
        System.out.println("periodo:"+Maysa.getCurso());
        System.out.println("-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*--*-*");
        System.out.println("-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*--*-*");

        //Mayque
  
        
        Mayque.Ajudar();
        Mayque.Estudar();
        Mayque.Comprar();
        Mayque.Faltar();
        Mayque.Atividade();
        Mayque.Reclamar();
        Mayque.Passar();
        
        System.out.println("Nome:"+Mayque.getNome());
        System.out.println("Idade:"+Mayque.getIdade());
        System.out.println("Cor:"+Mayque.getCor());
        System.out.println("Necessidade Especial :"+Mayque.isNecessiadeespecial());
        System.out.println("RA :"+Mayque.getRA());
        System.out.println("curso:"+Mayque.getPeriodo());
        System.out.println("periodo:"+Mayque.getCurso());
        System.out.println("-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*--*-*");
        System.out.println("-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*--*-*");

        //Maria 
  
        
        Maria.Ajudar();
        Maria.Estudar();
        Maria.Comprar();
        Maria.Faltar();
        Maria.Atividade();
        Maria.Reclamar();
        Maria.Passar();
        
        System.out.println("Nome:"+Maria.getNome());
        System.out.println("Idade:"+Maria.getIdade());
        System.out.println("Cor:"+Maria.getCor());
        System.out.println("Necessidade Especial :"+Maria.isNecessiadeespecial());
        System.out.println("RA :"+Maria.getRA());
        System.out.println("curso:"+Maria.getPeriodo());
        System.out.println("periodo:"+Maria.getCurso());
        System.out.println("-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*--*-*");
        System.out.println("-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*--*-*");        
    }
}
